﻿import os
import cv2 as cv
import numpy as np
import pandas as pd

from sklearn.cluster import MiniBatchKMeans


# =========================================================
# KONFIGURATION
# =========================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GROUND_TRUTH_DIR = os.path.join(SCRIPT_DIR, "ground_truth_dataset")

MANIFEST_PATH = os.path.join(GROUND_TRUTH_DIR, "ground_truth_manifest.csv")

OUTPUT_CSV = os.path.join(GROUND_TRUTH_DIR, "ground_truth_with_sift.csv")

FAILED_IMAGES_CSV = os.path.join(GROUND_TRUTH_DIR, "sift_failed_images.csv")

VOCAB_SIZE = 40
MAX_DESCRIPTORS_PER_IMAGE = 50
RANDOM_STATE = 42


# =========================================================
# HJÃ†LPEFUNKTIONER
# =========================================================

def validate_manifest_columns(df):
    required_columns = ["tile_image_path", "label", "image_id", "row", "col"]
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise ValueError(
            f"Manifest mangler nÃ¸dvendige kolonner: {missing}\n"
            f"TilgÃ¦ngelige kolonner: {list(df.columns)}"
        )


def create_sift():
    try:
        return cv.SIFT_create()
    except AttributeError as e:
        raise RuntimeError(
            "Din OpenCV-installation understÃ¸tter ikke SIFT. "
            "PrÃ¸v: pip install opencv-contrib-python"
        ) from e


def resolve_local_path(path_value):
    if not isinstance(path_value, str) or not path_value.strip():
        return path_value
    if os.path.isabs(path_value):
        return path_value

    candidates = [
        path_value,
        os.path.join(SCRIPT_DIR, path_value),
        os.path.join(os.path.dirname(MANIFEST_PATH), path_value),
    ]

    seen = set()
    for candidate in candidates:
        normalized = os.path.normpath(candidate)
        if normalized in seen:
            continue
        seen.add(normalized)
        if os.path.isfile(normalized):
            return normalized

    return os.path.normpath(os.path.join(SCRIPT_DIR, path_value))


def load_image_grayscale(image_path):
    if not isinstance(image_path, str) or not image_path.strip():
        raise ValueError(f"Ugyldig billedsti: {image_path}")

    image_path = resolve_local_path(image_path)

    if not os.path.isfile(image_path):
        raise FileNotFoundError(f"Billedfil findes ikke: {image_path}")

    image = cv.imread(image_path, cv.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError(f"OpenCV kunne ikke lÃ¦se billedet: {image_path}")

    return image

def extract_sift_descriptors(image_gray, sift):
    keypoints, descriptors = sift.detectAndCompute(image_gray, None)

    if descriptors is None or len(descriptors) == 0:
        return np.empty((0, 128), dtype=np.float32), 0

    if len(descriptors) > MAX_DESCRIPTORS_PER_IMAGE:
        descriptors = descriptors[:MAX_DESCRIPTORS_PER_IMAGE]

    return descriptors.astype(np.float32), len(keypoints)


def collect_all_descriptors(manifest_df, sift):
    all_descriptors = []
    per_image_descriptors = []
    failed_images = []

    total = len(manifest_df)

    for idx, row in manifest_df.iterrows():
        image_path = row["tile_image_path"]

        try:
            image_gray = load_image_grayscale(image_path)
            descriptors, num_keypoints = extract_sift_descriptors(image_gray, sift)

            per_image_descriptors.append({
                "manifest_index": idx,
                "descriptors": descriptors,
                "num_keypoints": num_keypoints
            })

            if len(descriptors) > 0:
                all_descriptors.append(descriptors)

        except Exception as e:
            per_image_descriptors.append({
                "manifest_index": idx,
                "descriptors": np.empty((0, 128), dtype=np.float32),
                "num_keypoints": 0
            })

            failed_images.append({
                "manifest_index": idx,
                "image_id": row.get("image_id", None),
                "row": row.get("row", None),
                "col": row.get("col", None),
                "tile_image_path": image_path,
                "error": str(e)
            })

        if (idx + 1) % 50 == 0 or (idx + 1) == total:
            print(f"Descriptors behandlet: {idx + 1}/{total}")

    if all_descriptors:
        all_descriptors = np.vstack(all_descriptors)
    else:
        all_descriptors = np.empty((0, 128), dtype=np.float32)

    return all_descriptors, per_image_descriptors, failed_images


def build_visual_vocabulary(all_descriptors):
    if len(all_descriptors) == 0:
        raise ValueError("Ingen SIFT-descriptors fundet i datasÃ¦ttet.")

    if len(all_descriptors) < VOCAB_SIZE:
        raise ValueError(
            f"For fÃ¥ descriptors ({len(all_descriptors)}) til VOCAB_SIZE={VOCAB_SIZE}. "
            "SÃ¦nk VOCAB_SIZE."
        )

    kmeans = MiniBatchKMeans(
        n_clusters=VOCAB_SIZE,
        random_state=RANDOM_STATE,
        batch_size=1024,
        n_init=10
    )
    kmeans.fit(all_descriptors)
    return kmeans


def descriptors_to_histogram(descriptors, kmeans):
    hist = np.zeros(VOCAB_SIZE, dtype=np.float32)

    if descriptors is None or len(descriptors) == 0:
        return hist

    cluster_ids = kmeans.predict(descriptors)

    for cid in cluster_ids:
        hist[cid] += 1.0

    if hist.sum() > 0:
        hist = hist / hist.sum()

    return hist


def build_feature_dataset(manifest_df, per_image_descriptors, kmeans):
    records = []

    for item in per_image_descriptors:
        idx = item["manifest_index"]
        descriptors = item["descriptors"]
        num_keypoints = item["num_keypoints"]

        row = manifest_df.iloc[idx]
        hist = descriptors_to_histogram(descriptors, kmeans)

        record = row.to_dict()
        record["num_sift_keypoints"] = int(num_keypoints)

        for i, value in enumerate(hist):
            record[f"sift_{i}"] = float(value)

        records.append(record)

    return pd.DataFrame(records)


# =========================================================
# MAIN
# =========================================================

def main():
    print("+------------------------------------------------------+")
    print("| King Domino HSV + SIFT feature builder              |")
    print("+------------------------------------------------------+")

    if not os.path.isfile(MANIFEST_PATH):
        print(f"Manifest ikke fundet:\n{MANIFEST_PATH}")
        return

    manifest_df = pd.read_csv(MANIFEST_PATH)
    validate_manifest_columns(manifest_df)

    print(f"Manifest indlÃ¦st: {MANIFEST_PATH}")
    print(f"Antal tiles i manifest: {len(manifest_df)}")

    sift = create_sift()

    all_descriptors, per_image_descriptors, failed_images = collect_all_descriptors(
        manifest_df, sift
    )

    print(f"Samlet antal descriptors: {len(all_descriptors)}")

    kmeans = build_visual_vocabulary(all_descriptors)
    result_df = build_feature_dataset(manifest_df, per_image_descriptors, kmeans)
    failed_df = pd.DataFrame(failed_images)

    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)
    result_df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8")
    failed_df.to_csv(FAILED_IMAGES_CSV, index=False, encoding="utf-8")

    sift_cols = [c for c in result_df.columns if c.startswith("sift_")]

    print("\nFÃ¦rdig.")
    print(f"Antal rÃ¦kker i output: {len(result_df)}")
    print(f"Antal SIFT-features pr tile: {len(sift_cols)}")
    print(f"Output gemt i:\n{OUTPUT_CSV}")
    print(f"Fejllog gemt i:\n{FAILED_IMAGES_CSV}")

    if "label" in result_df.columns:
        print("\nLabel-fordeling:")
        print(result_df["label"].value_counts())

    print("\nEksempel pÃ¥ kolonner:")
    print(result_df.columns[:20].tolist())


if __name__ == "__main__":
    main()

