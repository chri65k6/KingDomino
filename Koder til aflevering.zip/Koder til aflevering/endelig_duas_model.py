import argparse
import os

from kingdomino_feature_pipeline import train_model_package


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

DEFAULT_MANIFEST_PATH = os.path.join(
    SCRIPT_DIR,
    "ground_truth_dataset",
    "ground_truth_manifest.csv",
)
DEFAULT_MODEL_OUTPUT_PATH = os.path.join(
    SCRIPT_DIR,
    "king_domino_final_model.pkl",
)
DEFAULT_FEATURE_OUTPUT_PATH = os.path.join(
    SCRIPT_DIR,
    "ground_truth_dataset",
    "training_features_hsv_sift_hog.csv",
)

# Best parameters from sift_hsv_hog_balance_test.py
BEST_C = 100
BEST_GAMMA = 0.01
BEST_HSV_WEIGHT = 0.85
BEST_SIFT_WEIGHT = 0.10
BEST_HOG_WEIGHT = 0.05
SVM_KERNEL = "rbf"


def parse_args():
    parser = argparse.ArgumentParser(
        description="Train the final King Domino HSV + SIFT + HOG SVM model.",
    )
    parser.add_argument(
        "--manifest",
        default=DEFAULT_MANIFEST_PATH,
        help="Path to ground_truth_manifest.csv.",
    )
    parser.add_argument(
        "--model-output",
        default=DEFAULT_MODEL_OUTPUT_PATH,
        help="Where the trained model package should be saved.",
    )
    parser.add_argument(
        "--features-output",
        default=DEFAULT_FEATURE_OUTPUT_PATH,
        help="Optional CSV copy of the exact training features used by the final model.",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    print("Training final HSV + SIFT + HOG SVM model...")
    print(f"Manifest: {args.manifest}")
    print(f"Model output: {args.model_output}")

    model_package, feature_df = train_model_package(
        manifest_path=args.manifest,
        model_output_path=args.model_output,
        c=BEST_C,
        gamma=BEST_GAMMA,
        hsv_weight=BEST_HSV_WEIGHT,
        sift_weight=BEST_SIFT_WEIGHT,
        hog_weight=BEST_HOG_WEIGHT,
        kernel=SVM_KERNEL,
    )

    if args.features_output:
        os.makedirs(os.path.dirname(args.features_output), exist_ok=True)
        feature_df.to_csv(args.features_output, index=False, encoding="utf-8")

    print("\nDone.")
    print(f"Rows used for training: {len(feature_df)}")
    print(f"HSV columns: {len(model_package['hsv_cols'])}")
    print(f"SIFT columns: {len(model_package['sift_cols'])}")
    print(f"HOG columns: {len(model_package['hog_cols'])}")
    print(f"Classes: {', '.join(model_package['classes'])}")
    print(f"Saved model package: {args.model_output}")
    if args.features_output:
        print(f"Saved training features: {args.features_output}")


if __name__ == "__main__":
    main()
