import cv2 as cv
import pandas as pd
import os
import re
import glob


# =========================================================
# Basis-stier
# =========================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

IMAGE_FOLDER = os.path.join(BASE_DIR, "King_Domino_dataset")
CSV_FOLDER = os.path.join(BASE_DIR, "tile_data")

OUTPUT_BASE_FOLDER = os.path.join(BASE_DIR, "processed_tiles")
OUTPUT_SUMMARY_CSV = os.path.join(BASE_DIR, "all_tiles_with_ground_truth.csv")

ROWS = 5
COLS = 5
EXPECTED_IMAGE_SIZE = 500
CENTER_CROP_RATIO = 1.0   # fx 1.0 = hele tile, 0.8 = midterste 80%


# =========================================================
# Find alle CSV-filer med mønster tile_data_*.csv
# =========================================================
def find_csv_files(csv_folder):
    pattern = os.path.join(csv_folder, "tile_data_*.csv")
    files = sorted(glob.glob(pattern))

    if not files:
        raise FileNotFoundError(f"Ingen CSV-filer fundet med mønster: {pattern}")

    return files


# =========================================================
# Udtræk billede-id fra filnavn
# Eksempel:
# tile_data_3.csv -> 3
# tile_data_hist_12.csv -> 12
# =========================================================
def extract_image_id(filename):
    basename = os.path.basename(filename)

    match = re.search(r"(\d+)(?=\.csv$)", basename)
    if not match:
        return None

    return int(match.group(1))


# =========================================================
# Find tilhørende billede
# Prøver flere filendelser
# =========================================================
def find_matching_image(image_folder, image_id):
    possible_extensions = [".jpg", ".jpeg", ".png", ".bmp"]

    for ext in possible_extensions:
        candidate = os.path.join(image_folder, f"{image_id}{ext}")
        if os.path.isfile(candidate):
            return candidate

    return None


# =========================================================
# Læs ground truth fra CSV
# Hvis label-kolonnen ikke har et navn, bruges sidste kolonne
# =========================================================
def load_ground_truth(csv_path):
    df = pd.read_csv(csv_path, sep=None, engine="python")

    if df.empty:
        raise ValueError(f"CSV-filen er tom: {csv_path}")

    possible_label_cols = ["label", "terrain", "class", "type", "valid_label"]
    label_col = None

    for col in df.columns:
        if str(col).strip().lower() in possible_label_cols:
            label_col = col
            break

    if label_col is None:
        label_col = df.columns[-1]

    labels = df[label_col].tolist()

    if len(labels) != 25:
        raise ValueError(
            f"CSV '{os.path.basename(csv_path)}' skal have 25 labels, men har {len(labels)}."
        )

    return labels, df, label_col


# =========================================================
# Split billede i fast 5x5 grid
# =========================================================
def split_into_tiles(image, rows=5, cols=5, center_crop_ratio=1.0):
    h, w = image.shape[:2]

    if h != EXPECTED_IMAGE_SIZE or w != EXPECTED_IMAGE_SIZE:
        raise ValueError(
            f"Billedet skal være {EXPECTED_IMAGE_SIZE}x{EXPECTED_IMAGE_SIZE}, men er {w}x{h}."
        )

    tile_h = h // rows
    tile_w = w // cols

    tiles = []

    for row in range(rows):
        for col in range(cols):
            y1 = row * tile_h
            y2 = (row + 1) * tile_h
            x1 = col * tile_w
            x2 = (col + 1) * tile_w

            tile = image[y1:y2, x1:x2]

            if center_crop_ratio < 1.0:
                ch, cw = tile.shape[:2]
                crop_h = int(ch * center_crop_ratio)
                crop_w = int(cw * center_crop_ratio)

                start_y = (ch - crop_h) // 2
                start_x = (cw - crop_w) // 2

                tile = tile[start_y:start_y + crop_h, start_x:start_x + crop_w]

            tiles.append({
                "row": row,
                "col": col,
                "x1": x1,
                "y1": y1,
                "x2": x2,
                "y2": y2,
                "tile": tile
            })

    return tiles


# =========================================================
# Gem tiles for ét billede
# =========================================================
def save_tiles(tiles, output_folder, image_id):
    os.makedirs(output_folder, exist_ok=True)

    for item in tiles:
        row = item["row"]
        col = item["col"]
        tile = item["tile"]

        filename = f"image_{image_id}_r{row}_c{col}.png"
        filepath = os.path.join(output_folder, filename)

        ok = cv.imwrite(filepath, tile)
        if not ok:
            print(f"Advarsel: kunne ikke gemme {filepath}")


# =========================================================
# Lav dataframe for ét billede
# =========================================================
def build_tile_dataframe(image_id, image_path, csv_path, tiles, labels):
    rows = []

    for i, item in enumerate(tiles):
        row = item["row"]
        col = item["col"]
        x1 = item["x1"]
        y1 = item["y1"]
        x2 = item["x2"]
        y2 = item["y2"]

        rows.append({
            "image_id": image_id,
            "image_path": image_path,
            "csv_path": csv_path,
            "tile_index": i,
            "row": row,
            "col": col,
            "x1": x1,
            "y1": y1,
            "x2": x2,
            "y2": y2,
            "label": labels[i]
        })

    return pd.DataFrame(rows)


# =========================================================
# Behandl én CSV + tilhørende billede
# =========================================================
def process_one_pair(csv_path):
    image_id = extract_image_id(csv_path)

    if image_id is None:
        print(f"Springer over, kunne ikke finde nummer i filnavn: {csv_path}")
        return None

    image_path = find_matching_image(IMAGE_FOLDER, image_id)

    if image_path is None:
        print(f"Springer over: intet billede fundet til image_id={image_id}")
        return None

    image = cv.imread(image_path)
    if image is None:
        print(f"Springer over: kunne ikke læse billede {image_path}")
        return None

    labels, _, label_col = load_ground_truth(csv_path)

    tiles = split_into_tiles(
        image=image,
        rows=ROWS,
        cols=COLS,
        center_crop_ratio=CENTER_CROP_RATIO
    )

    output_tile_folder = os.path.join(OUTPUT_BASE_FOLDER, f"image_{image_id}")
    save_tiles(tiles, output_tile_folder, image_id)

    df = build_tile_dataframe(
        image_id=image_id,
        image_path=image_path,
        csv_path=csv_path,
        tiles=tiles,
        labels=labels
    )

    print(f"Behandlet image_id={image_id} | label-kolonne: {label_col}")

    return df


# =========================================================
# Main
# =========================================================
def main():
    print("+---------------------------------------------------+")
    print("| King Domino batch tile extractor with CSV labels  |")
    print("+---------------------------------------------------+")

    print(f"Script-mappe: {BASE_DIR}")
    print(f"Billedmappe:   {IMAGE_FOLDER}")
    print(f"CSV-mappe:     {CSV_FOLDER}")

    try:
        csv_files = find_csv_files(CSV_FOLDER)
        print(f"Fandt {len(csv_files)} CSV-filer.")

        all_dfs = []

        for csv_path in csv_files:
            try:
                df = process_one_pair(csv_path)
                if df is not None:
                    all_dfs.append(df)
            except Exception as e:
                print(f"Fejl i fil {os.path.basename(csv_path)}: {e}")

        if not all_dfs:
            print("Ingen filer blev behandlet korrekt.")
            return

        final_df = pd.concat(all_dfs, ignore_index=True)
        final_df.to_csv(OUTPUT_SUMMARY_CSV, index=False, sep=";")

        print()
        print("Færdig.")
        print(f"Antal behandlede tiles: {len(final_df)}")
        print(f"Forventet antal hvis 20 billeder virker: {20 * 25} = 500")
        print(f"Samlet CSV gemt som: {OUTPUT_SUMMARY_CSV}")
        print(f"Tile-billeder gemt i: {OUTPUT_BASE_FOLDER}")

    except Exception as e:
        print(f"Fatal fejl: {e}")


if __name__ == "__main__":
    main()
