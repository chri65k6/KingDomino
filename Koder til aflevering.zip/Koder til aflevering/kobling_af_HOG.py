﻿import os
import cv2 as cv
import pandas as pd
from skimage.feature import hog


# =========================================================
# KONFIGURATION
# =========================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GROUND_TRUTH_DIR = os.path.join(SCRIPT_DIR, "ground_truth_dataset")

MANIFEST_PATH = os.path.join(GROUND_TRUTH_DIR, "ground_truth_manifest.csv")

OUTPUT_CSV = os.path.join(GROUND_TRUTH_DIR, "ground_truth_with_hog.csv")

FAILED_IMAGES_CSV = os.path.join(GROUND_TRUTH_DIR, "hog_failed_images.csv")

# HOG-parametre
HOG_ORIENTATIONS = 8
HOG_PIXELS_PER_CELL = (30, 30)
HOG_CELLS_PER_BLOCK = (2, 2)
HOG_BLOCK_NORM = "L2-Hys"


# =========================================================
# HJÃ†LPEFUNKTIONER
# =========================================================

def validate_manifest_columns(df):
    required_columns = ["tile_image_path", "label", "image_id", "row", "col"]
    missing = [col for col in required_columns if col not in df.columns]

    if missing:
        raise ValueError(
            f"Manifest mangler nÃ¸dvendige kolonner: {missing}\n"
            f"TilgÃ¦ngelige kolonner: {list(df.columns)}"
        )


def resolve_local_path(path_value):
    if not isinstance(path_value, str) or not path_value.strip():
        return path_value
    if os.path.isabs(path_value):
        return path_value

    candidates = [
        path_value,
        os.path.join(SCRIPT_DIR, path_value),
        os.path.join(os.path.dirname(MANIFEST_PATH), path_value),
    ]

    seen = set()
    for candidate in candidates:
        normalized = os.path.normpath(candidate)
        if normalized in seen:
            continue
        seen.add(normalized)
        if os.path.isfile(normalized):
            return normalized

    return os.path.normpath(os.path.join(SCRIPT_DIR, path_value))


def load_image_grayscale(image_path):
    if not isinstance(image_path, str) or not image_path.strip():
        raise ValueError(f"Ugyldig billedsti: {image_path}")

    image_path = resolve_local_path(image_path)

    if not os.path.isfile(image_path):
        raise FileNotFoundError(f"Billedfil findes ikke: {image_path}")

    image = cv.imread(image_path, cv.IMREAD_GRAYSCALE)

    if image is None:
        raise ValueError(f"OpenCV kunne ikke lÃ¦se billedet: {image_path}")

    height, width = image.shape

    if height < 10 or width < 10:
        raise ValueError(
            f"Billedet er for lille til HOG: {image_path} -> {width}x{height}"
        )

    return image, width, height

def extract_hog_features(image_gray):
    height, width = image_gray.shape

    ppc_y, ppc_x = HOG_PIXELS_PER_CELL
    cpb_y, cpb_x = HOG_CELLS_PER_BLOCK

    cells_y = height // ppc_y
    cells_x = width // ppc_x

    if cells_y < cpb_y or cells_x < cpb_x:
        raise ValueError(
            f"Billedet er for lille til valgte HOG-parametre. "
            f"Shape={width}x{height}, "
            f"pixels_per_cell={HOG_PIXELS_PER_CELL}, "
            f"cells_per_block={HOG_CELLS_PER_BLOCK}"
        )

    features = hog(
        image_gray,
        orientations=HOG_ORIENTATIONS,
        pixels_per_cell=HOG_PIXELS_PER_CELL,
        cells_per_block=HOG_CELLS_PER_BLOCK,
        block_norm=HOG_BLOCK_NORM,
        visualize=False,
        feature_vector=True
    )

    return features


def build_feature_dataset(manifest_df):
    records = []
    failed_images = []
    size_counter = {}

    total = len(manifest_df)

    for idx, row in manifest_df.iterrows():
        image_path = row["tile_image_path"]

        try:
            image_gray, width, height = load_image_grayscale(image_path)

            size_key = f"{width}x{height}"
            size_counter[size_key] = size_counter.get(size_key, 0) + 1

            hog_features = extract_hog_features(image_gray)

            record = row.to_dict()
            record["img_width"] = width
            record["img_height"] = height

            for i, value in enumerate(hog_features):
                record[f"hog_{i}"] = float(value)

            records.append(record)

        except Exception as e:
            failed_images.append({
                "manifest_index": idx,
                "image_id": row.get("image_id", None),
                "row": row.get("row", None),
                "col": row.get("col", None),
                "tile_image_path": image_path,
                "error": str(e)
            })

            if len(failed_images) <= 10:
                print(f"\n[FEJL {len(failed_images)}]")
                print(f"image_id={row.get('image_id', None)}, row={row.get('row', None)}, col={row.get('col', None)}")
                print(f"sti={image_path}")
                print(f"fejl={e}")

        if (idx + 1) % 50 == 0 or (idx + 1) == total:
            print(f"Behandlet {idx + 1}/{total} tiles")

    result_df = pd.DataFrame(records)
    failed_df = pd.DataFrame(failed_images)

    return result_df, failed_df, size_counter


def print_dataset_info(result_df, failed_df, size_counter):
    print("\nFÃ¦rdig.")
    print(f"Antal succesfulde tiles: {len(result_df)}")
    print(f"Antal fejlende tiles: {len(failed_df)}")

    if size_counter:
        print("\nFundne billedstÃ¸rrelser:")
        for k, v in sorted(size_counter.items()):
            print(f"{k}: {v}")

    if not result_df.empty:
        hog_columns = [col for col in result_df.columns if col.startswith("hog_")]
        print(f"Antal HOG-features pr tile: {len(hog_columns)}")

        if "label" in result_df.columns:
            print("\nLabel-fordeling:")
            print(result_df["label"].value_counts())

        hsv_cols = [col for col in ["hue", "saturation", "value"] if col in result_df.columns]
        if hsv_cols:
            print(f"\nHSV-kolonner fundet: {hsv_cols}")


# =========================================================
# MAIN
# =========================================================

def main():
    print("+------------------------------------------------------+")
    print("| King Domino HSV + HOG feature builder               |")
    print("+------------------------------------------------------+")

    if not os.path.isfile(MANIFEST_PATH):
        print(f"Manifest ikke fundet:\n{MANIFEST_PATH}")
        return

    manifest_df = pd.read_csv(MANIFEST_PATH)
    validate_manifest_columns(manifest_df)

    print(f"Manifest indlÃ¦st: {MANIFEST_PATH}")
    print(f"Antal tiles i manifest: {len(manifest_df)}")
    print("Kolonner i manifest:")
    print(list(manifest_df.columns))

    result_df, failed_df, size_counter = build_feature_dataset(manifest_df)

    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)

    if not result_df.empty:
        result_df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8")
        print(f"\nOutput gemt i:\n{OUTPUT_CSV}")
    else:
        print("\nIngen features blev genereret.")

    failed_df.to_csv(FAILED_IMAGES_CSV, index=False, encoding="utf-8")
    print(f"Fejllog gemt i:\n{FAILED_IMAGES_CSV}")

    print_dataset_info(result_df, failed_df, size_counter)


if __name__ == "__main__":
    main()

