import cv2 as cv
import numpy as np
import os
import csv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGE_FOLDER = os.path.join(BASE_DIR, "King_Domino_dataset")
TILE_DATA_FOLDER = os.path.join(BASE_DIR, "tile_data")

# Main function containing the backbone of the program
def main():
    print("+-------------------------------+")
    print("| King Domino points calculator |")
    print("+-------------------------------+")
    image_path = os.path.join(IMAGE_FOLDER, "45.jpg")
    if not os.path.isfile(image_path):
        print("Image not found")
        return

    image = cv.imread(image_path)
    tiles = get_tiles(image)

    # Gem tile data i en CSV-fil
    save_tile_data(tiles)

    print(f"Der er gemt HSV-data for {len(tiles)*len(tiles[0])} tiles i 'tile_data.csv'.")

# Break a board into tiles
def get_tiles(image):
    tiles = []
    for y in range(5):
        tiles.append([])
        for x in range(5):
            tiles[-1].append(image[y*100:(y+1)*100, x*100:(x+1)*100])
    return tiles

# Save HSV values from all tiles into a CSV file
def save_tile_data(tiles):
    os.makedirs(TILE_DATA_FOLDER, exist_ok=True)
    i = 1
    while os.path.exists(os.path.join(TILE_DATA_FOLDER, f"tile_data_{i}.csv")):
        i += 1
    filename = os.path.join(TILE_DATA_FOLDER, f"tile_data_{i}.csv")

    with open(filename, "w", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(["x", "y", "hue", "saturation", "value"])
        for y, row in enumerate(tiles):
            for x, tile in enumerate(row):
                hsv_tile = cv.cvtColor(tile, cv.COLOR_BGR2HSV)
                h, s, v = np.median(hsv_tile, axis=(0, 1))
                writer.writerow([x, y, h, s, v])

    print(f"HSV-data gemt i: {filename}")


if __name__ == "__main__":
    main()
