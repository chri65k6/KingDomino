`Koder til aflevering` er samlet som en selvstaendig mappe med den pipeline, der leder frem til den endelige model `king_domino_final_model.pkl`.

Formaalet med mappen er at samle:
- de scripts der bruges i den valgte pipeline
- de vigtigste mellemresultater og datasaet
- den endelige model og de features den blev traenet paa

Det betyder, at mappen baade indeholder kode og allerede genererede artefakter.

**Overblik**
Den valgte pipeline kan deles i seks trin:
1. Generering af `tile_data`
2. Generering af `processed_tiles`
3. Sammenkobling af tiles og labels til et manifest
4. Feature-udtraek for SIFT og HOG
5. Modeludvaelgelse via balance/grid search
6. Traening af den endelige model

Den vigtigste slutfil er:
- `king_domino_final_model.pkl`

Den vigtigste featurefil er:
- `ground_truth_dataset/training_features_hsv_sift_hog.csv`

**Mappeindhold**
Filer i rodmappen:
- `tileprocessing.py`
  Bruger hele board-billeder og labels til at splitte boards i 5x5 tiles og gemme tile-billeder i `processed_tiles/`. Scriptet laver ogsaa en samlet oversigt i `all_tiles_with_ground_truth.csv`.
- `CSV_file_maker.py`
  Simpel generator af en `tile_data_*.csv` fil for et enkelt board-billede. Den ser ud til at vaere en tidlig eller manuel version og ikke en fuld batch-pipeline.
- `kode_til_kobling_af_tile_og_label.py`
  Matcher `tile_data/*.csv` med tile-billeder i `processed_tiles/` og bygger et samlet manifest med labels og stier.
- `kobling_af_sift.py`
  Laeser manifestet og udregner SIFT-baserede features for hver tile. Output gemmes i `ground_truth_with_sift.csv`.
- `kobling_af_HOG.py`
  Laeser manifestet og udregner HOG-baserede features for hver tile. Output gemmes i `ground_truth_with_hog.csv`.
- `sift_hsv_hog_balance_test.py`
  Merger SIFT- og HOG-featurefilerne, identificerer HSV/SIFT/HOG-kolonner, tester forskellige feature-vaegte og SVM-parametre med `GridSearchCV`, og gemmer modeludvaelgelsesresultater.
- `kingdomino_feature_pipeline.py`
  Den centrale feature- og modelpipeline. Indeholder funktioner til HSV-, SIFT- og HOG-featureudtraek, opbygning af traeningsdata og traening/indlaesning af modelpakker.
- `endelig_duas_model.py`
  Bygger den endelige model med de valgte bedste parametre og gemmer baade modelpakken og den konkrete featurematrix, den er traenet paa.
- `king_domino_final_model.pkl`
  Den endelige traenede modelpakke.

Mapper i afleveringsmappen:
- `ground_truth_dataset/`
  Samlet datasæt og mellemresultater til traening.
- `model_selection_results/`
  Resultater fra balance/grid search.
- `processed_tiles/`
  De tile-billeder der bruges som input til manifest og featureudtraek.
- `tile_data/`
  CSV-filer med tile-koordinater, HSV-vaerdier og labels.

**Beskrivelse Af Datafiler**
Indhold i `ground_truth_dataset/`:
- `ground_truth_manifest.csv`
  Samlet manifest over alle tiles. Indeholder blandt andet `image_id`, `row`, `col`, `label`, `tile_image_path` og `csv_file`. Denne fil er bindeleddet mellem de raa tiles og feature-trinnene.
- `ground_truth_with_sift.csv`
  Manifestdata udvidet med SIFT-features og `num_sift_keypoints`.
- `ground_truth_with_hog.csv`
  Manifestdata udvidet med HOG-features.
- `training_features_hsv_sift_hog.csv`
  Den featurefil den endelige model blev traenet paa. Indeholder HSV-, SIFT- og HOG-features i samme tabel.
- `dataset_summary.txt`
  Kort tekstopsummering af det genererede manifest/datasæt.
- `missing_images.csv`
  Eventuelle CSV-rækker som ikke kunne matches med et tile-billede.
- `images_without_csv_match.csv`
  Eventuelle tile-billeder som ikke kunne matches til en CSV-række.
- `duplicate_csv_keys.csv`
  Eventuelle dubletter i `(image_id, row, col)`-nøgler fra CSV-siden.
- `sift_failed_images.csv`
  Eventuelle tiles hvor SIFT-featureudtraek fejlede.
- `hog_failed_images.csv`
  Eventuelle tiles hvor HOG-featureudtraek fejlede.

Indhold i `model_selection_results/`:
- `grid_search_hsv_sift_hog_merged_results.csv`
  Resultattabel fra balance-testen for den kombinerede HSV + SIFT + HOG model. Indeholder scores, rank og de testede vaegte/parametre.

Andre data:
- `all_tiles_with_ground_truth.csv`
  Samlet oversigt fra `tileprocessing.py` over tiles, deres koordinater og labels.

**Konkret Pipeline**
Den pipeline der munder ud i den endelige model er:
1. `tileprocessing.py` og/eller `CSV_file_maker.py`
   Skaber de tidlige inputs `processed_tiles/` og `tile_data/`.
2. `kode_til_kobling_af_tile_og_label.py`
   Skaber `ground_truth_dataset/ground_truth_manifest.csv`.
3. `kobling_af_sift.py`
   Skaber `ground_truth_dataset/ground_truth_with_sift.csv`.
4. `kobling_af_HOG.py`
   Skaber `ground_truth_dataset/ground_truth_with_hog.csv`.
5. `sift_hsv_hog_balance_test.py`
   Finder gode feature-vaegte og SVM-parametre.
6. `endelig_duas_model.py`
   Traener den endelige model og gemmer:
   `king_domino_final_model.pkl`
   `ground_truth_dataset/training_features_hsv_sift_hog.csv`

**Hvad Den Endelige Pipeline Bruges Til**
Den endelige pipeline bruges ikke til at eksperimentere bredt, men til at bygge den model der faktisk skal bruges bagefter.

Mere konkret:
- den laeser det ground-truth datasæt der er bygget op gennem pipeline-trinnene
- den udtraekker og kombinerer HSV-, SIFT- og HOG-features
- den traener en endelig `SVM`
- den gemmer en modelpakke i `king_domino_final_model.pkl`

Denne modelpakke kan derefter bruges til prediction paa nye Kingdomino-braetter eller nye tiles.

**Om De To Tidlige Trin**
Der er en vigtig praktisk pointe:
- `processed_tiles/` kan tydeligt spores til `tileprocessing.py`
- den eneste klare generator jeg fandt for `tile_data` i repoet er `CSV_file_maker.py`

Det betyder, at `CSV_file_maker.py` sandsynligvis er en mere manuel eller tidlig version. Hvis der har eksisteret en anden batch-generator for `tile_data`, har jeg ikke kunnet finde den sikkert i repoet.

**Stier Og Selvstaendighed**
Kopierne i denne mappe er justeret, saa de bruger lokale stier inde i `Koder til aflevering` i stedet for at pege tilbage paa gamle projektmapper.

Det gaelder isaer:
- `kode_til_kobling_af_tile_og_label.py`
- `kobling_af_sift.py`
- `kobling_af_HOG.py`
- `sift_hsv_hog_balance_test.py`
- `tileprocessing.py`
- `CSV_file_maker.py`
- `kingdomino_feature_pipeline.py`

Det er gjort for at afleveringsmappen bedre kan staa alene.

**Forudsaetninger For At Koere Alt Fra Bunden**
Hvis hele kaeden skal kunne koeres helt fra bunden, skal foelgende input findes:
- `tile_data/`
- `processed_tiles/`
- eventuelt `King_Domino_dataset/` hvis man vil regenerere tiles fra de originale board-billeder

Lige nu indeholder afleveringsmappen `tile_data/` og `processed_tiles/`, men ikke automatisk `King_Domino_dataset/`.

**Typisk Koerselsraekke**
Hvis man vil genskabe hele modellen fra de mellemste trin i afleveringsmappen, er den normale raekke:
1. `python "Koder til aflevering\\kode_til_kobling_af_tile_og_label.py"`
2. `python "Koder til aflevering\\kobling_af_sift.py"`
3. `python "Koder til aflevering\\kobling_af_HOG.py"`
4. `python "Koder til aflevering\\sift_hsv_hog_balance_test.py"`
5. `python "Koder til aflevering\\endelig_duas_model.py"`

Hvis man ogsaa vil regenerere de tidlige input:
1. generer `tile_data/`
2. generer `processed_tiles/`
3. koer derefter ovenstaaende pipeline

**Status For Validering**
Jeg har verificeret:
- at manifest-trinnet kunne koere paa afleveringskopierne
- at SIFT- og HOG-trinnene kunne koere paa afleveringskopierne
- at `endelig_duas_model.py` kunne koere og skrive model samt traeningsfeatures i afleveringsmappen

Balance-testen kan koere, men parallel koersel med `n_jobs=-1` ramte i denne session en Windows/joblib rettighedsfejl i sandbox-miljoeet. Det siger noget om miljoeet her, ikke noedvendigvis om scriptet paa din egen maskine uden samme begrænsning.
