import os
import pickle

import cv2 as cv
import numpy as np
import pandas as pd
from skimage.feature import hog as skimage_hog
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.cluster import MiniBatchKMeans
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import SVC


BOARD_SIZE = 5
DEFAULT_TILE_SIZE = (100, 100)  # width, height for cv.resize

HOG_ORIENTATIONS = 8
HOG_PIXELS_PER_CELL = (30, 30)
HOG_CELLS_PER_BLOCK = (2, 2)
HOG_BLOCK_NORM = "L2-Hys"

SIFT_VOCAB_SIZE = 40
SIFT_MAX_DESCRIPTORS_PER_IMAGE = 50
RANDOM_STATE = 42


def unique_preserve_order(seq):
    return list(dict.fromkeys(seq))


def detect_hsv_columns(df):
    exact_names = {
        "hue", "saturation", "value",
        "mean_h", "mean_s", "mean_v",
        "std_h", "std_s", "std_v",
    }
    prefixes = (
        "hsv_", "hist_h_", "hist_s_", "hist_v_",
        "h_bin_", "s_bin_", "v_bin_",
    )
    contains_tokens = ("hue", "saturation", "value", "hsv")

    cols = []
    for col in df.columns:
        c = col.lower()
        if c in exact_names:
            cols.append(col)
        elif c.startswith(prefixes):
            cols.append(col)
        elif any(token in c for token in contains_tokens):
            if c not in ("label", "image_id"):
                cols.append(col)

    return unique_preserve_order(cols)


def detect_sift_columns(df):
    cols = []
    for col in df.columns:
        c = col.lower()
        if "sift" in c and c not in ("label", "image_id"):
            cols.append(col)
    return unique_preserve_order(cols)


def detect_hog_columns(df):
    cols = []
    for col in df.columns:
        c = col.lower()
        if "hog" in c and c not in ("label", "image_id"):
            cols.append(col)
    return unique_preserve_order(cols)


class MultiFeatureWeighter(BaseEstimator, TransformerMixin):
    def __init__(
        self,
        hsv_cols=None,
        sift_cols=None,
        hog_cols=None,
        hsv_weight=1.0,
        sift_weight=0.0,
        hog_weight=0.0,
    ):
        self.hsv_cols = hsv_cols
        self.sift_cols = sift_cols
        self.hog_cols = hog_cols
        self.hsv_weight = hsv_weight
        self.sift_weight = sift_weight
        self.hog_weight = hog_weight

    def fit(self, X, y=None):
        if not isinstance(X, pd.DataFrame):
            raise TypeError("MultiFeatureWeighter expects a pandas DataFrame.")

        self.hsv_cols_ = self.hsv_cols if self.hsv_cols is not None else detect_hsv_columns(X)
        self.sift_cols_ = self.sift_cols if self.sift_cols is not None else detect_sift_columns(X)
        self.hog_cols_ = self.hog_cols if self.hog_cols is not None else detect_hog_columns(X)

        if len(self.hsv_cols_) == 0:
            raise ValueError("No HSV columns found.")
        if len(self.sift_cols_) == 0:
            raise ValueError("No SIFT columns found.")
        if len(self.hog_cols_) == 0:
            raise ValueError("No HOG columns found.")

        self.hsv_scaler_ = StandardScaler()
        self.sift_scaler_ = StandardScaler()
        self.hog_scaler_ = StandardScaler()

        self.hsv_scaler_.fit(X[self.hsv_cols_])
        self.sift_scaler_.fit(X[self.sift_cols_])
        self.hog_scaler_.fit(X[self.hog_cols_])

        return self

    def transform(self, X):
        hsv_part = self.hsv_scaler_.transform(X[self.hsv_cols_]) * self.hsv_weight
        sift_part = self.sift_scaler_.transform(X[self.sift_cols_]) * self.sift_weight
        hog_part = self.hog_scaler_.transform(X[self.hog_cols_]) * self.hog_weight

        return np.hstack([hsv_part, sift_part, hog_part])


def validate_manifest_columns(df):
    required_columns = ["tile_image_path", "label", "image_id", "row", "col"]
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise ValueError(f"Manifest is missing required columns: {missing}")


def resolve_input_path(path_value, path_roots=None):
    if not isinstance(path_value, str) or not path_value.strip():
        return path_value
    if os.path.isabs(path_value):
        return path_value

    candidates = [path_value]
    for root in path_roots or []:
        if root:
            candidates.append(os.path.join(root, path_value))

    seen = set()
    for candidate in candidates:
        normalized = os.path.normpath(candidate)
        if normalized in seen:
            continue
        seen.add(normalized)
        if os.path.exists(normalized):
            return normalized

    if path_roots:
        return os.path.normpath(os.path.join(path_roots[0], path_value))
    return os.path.normpath(path_value)


def read_image_bgr(image_path):
    image = cv.imread(image_path)
    if image is None:
        raise ValueError(f"OpenCV could not read image: {image_path}")
    return image


def read_image_gray(image_path):
    image = cv.imread(image_path, cv.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError(f"OpenCV could not read image as grayscale: {image_path}")
    return image


def resize_tile(tile, tile_size=DEFAULT_TILE_SIZE):
    width, height = tile_size
    if tile.shape[1] == width and tile.shape[0] == height:
        return tile
    return cv.resize(tile, (width, height), interpolation=cv.INTER_AREA)


def tile_to_gray(tile):
    if len(tile.shape) == 2:
        return tile
    return cv.cvtColor(tile, cv.COLOR_BGR2GRAY)


def create_sift():
    try:
        return cv.SIFT_create()
    except AttributeError as exc:
        raise RuntimeError(
            "This OpenCV installation does not support SIFT. "
            "Install opencv-contrib-python."
        ) from exc


def extract_hsv_feature_values(tile, tile_size=DEFAULT_TILE_SIZE):
    tile = resize_tile(tile, tile_size)
    hsv = cv.cvtColor(tile, cv.COLOR_BGR2HSV)

    h = hsv[:, :, 0]
    s = hsv[:, :, 1]
    v = hsv[:, :, 2]

    median_h = float(np.median(h))
    median_s = float(np.median(s))
    median_v = float(np.median(v))

    values = {
        "hue": median_h,
        "saturation": median_s,
        "value": median_v,
        "mean_h": float(np.mean(h)),
        "mean_s": float(np.mean(s)),
        "mean_v": float(np.mean(v)),
        "std_h": float(np.std(h)),
        "std_s": float(np.std(s)),
        "std_v": float(np.std(v)),
        "hsv_hue": median_h,
        "hsv_saturation": median_s,
        "hsv_value": median_v,
    }
    return values


def extract_hog_feature_array(tile, tile_size=DEFAULT_TILE_SIZE):
    tile = resize_tile(tile, tile_size)
    gray = tile_to_gray(tile)
    return skimage_hog(
        gray,
        orientations=HOG_ORIENTATIONS,
        pixels_per_cell=HOG_PIXELS_PER_CELL,
        cells_per_block=HOG_CELLS_PER_BLOCK,
        block_norm=HOG_BLOCK_NORM,
        visualize=False,
        feature_vector=True,
    )


def extract_sift_descriptors(tile, sift, tile_size=DEFAULT_TILE_SIZE):
    tile = resize_tile(tile, tile_size)
    gray = tile_to_gray(tile)
    keypoints, descriptors = sift.detectAndCompute(gray, None)

    if descriptors is None or len(descriptors) == 0:
        return np.empty((0, 128), dtype=np.float32), 0

    if len(descriptors) > SIFT_MAX_DESCRIPTORS_PER_IMAGE:
        descriptors = descriptors[:SIFT_MAX_DESCRIPTORS_PER_IMAGE]

    return descriptors.astype(np.float32), len(keypoints)


def collect_sift_descriptors(manifest_df, tile_size=DEFAULT_TILE_SIZE, path_roots=None):
    sift = create_sift()
    all_descriptors = []
    per_tile = []

    for idx, row in manifest_df.iterrows():
        image_path = resolve_input_path(row["tile_image_path"], path_roots)
        try:
            tile = read_image_gray(image_path)
            descriptors, num_keypoints = extract_sift_descriptors(tile, sift, tile_size)
        except Exception:
            descriptors = np.empty((0, 128), dtype=np.float32)
            num_keypoints = 0

        per_tile.append({
            "manifest_index": idx,
            "descriptors": descriptors,
            "num_keypoints": num_keypoints,
        })

        if len(descriptors) > 0:
            all_descriptors.append(descriptors)

    if all_descriptors:
        all_descriptors = np.vstack(all_descriptors)
    else:
        all_descriptors = np.empty((0, 128), dtype=np.float32)

    return all_descriptors, per_tile


def build_sift_vocabulary(all_descriptors):
    if len(all_descriptors) == 0:
        raise ValueError("No SIFT descriptors found in training data.")
    if len(all_descriptors) < SIFT_VOCAB_SIZE:
        raise ValueError(
            f"Too few descriptors ({len(all_descriptors)}) for SIFT_VOCAB_SIZE={SIFT_VOCAB_SIZE}."
        )

    kmeans = MiniBatchKMeans(
        n_clusters=SIFT_VOCAB_SIZE,
        random_state=RANDOM_STATE,
        batch_size=1024,
        n_init=10,
    )
    kmeans.fit(all_descriptors)
    return kmeans


def descriptors_to_sift_histogram(descriptors, kmeans):
    hist = np.zeros(kmeans.n_clusters, dtype=np.float32)

    if descriptors is None or len(descriptors) == 0:
        return hist

    cluster_ids = kmeans.predict(descriptors)
    for cid in cluster_ids:
        hist[cid] += 1.0

    if hist.sum() > 0:
        hist = hist / hist.sum()

    return hist


def values_to_columns(values, expected_cols):
    return {col: float(values.get(col, 0.0)) for col in expected_cols}


def array_to_columns(values, expected_cols):
    arr = np.asarray(values, dtype=float)
    if len(arr) < len(expected_cols):
        arr = np.pad(arr, (0, len(expected_cols) - len(arr)))
    elif len(arr) > len(expected_cols):
        arr = arr[:len(expected_cols)]

    return {col: float(value) for col, value in zip(expected_cols, arr)}


def build_training_feature_dataframe_from_manifest_df(
    manifest_df,
    use_manifest_hsv=True,
    path_roots=None,
):
    manifest_df = manifest_df.copy().reset_index(drop=True)
    validate_manifest_columns(manifest_df)

    all_descriptors, per_tile_descriptors = collect_sift_descriptors(
        manifest_df,
        path_roots=path_roots,
    )
    sift_kmeans = build_sift_vocabulary(all_descriptors)

    records = []
    for idx, row in manifest_df.iterrows():
        image_path = resolve_input_path(row["tile_image_path"], path_roots)
        tile_bgr = resize_tile(read_image_bgr(image_path))
        tile_gray = resize_tile(read_image_gray(image_path))

        hsv_values = extract_hsv_feature_values(tile_bgr)
        if use_manifest_hsv:
            for col in ["hue", "saturation", "value"]:
                if col in manifest_df.columns and not pd.isna(row[col]):
                    hsv_values[col] = float(row[col])

        descriptor_info = per_tile_descriptors[idx]
        sift_hist = descriptors_to_sift_histogram(
            descriptor_info["descriptors"],
            sift_kmeans,
        )
        hog_features = extract_hog_feature_array(tile_gray)

        record = {
            "image_id": int(row["image_id"]),
            "row": int(row["row"]),
            "col": int(row["col"]),
            "label": str(row["label"]).strip().lower(),
            "tile_image_path": row["tile_image_path"],
            "hue": hsv_values["hue"],
            "saturation": hsv_values["saturation"],
            "value": hsv_values["value"],
            "num_sift_keypoints": int(descriptor_info["num_keypoints"]),
            "img_width": int(tile_bgr.shape[1]),
            "img_height": int(tile_bgr.shape[0]),
        }

        if "csv_file" in manifest_df.columns:
            record["csv_file"] = row["csv_file"]

        for i, value in enumerate(sift_hist):
            record[f"sift_{i}"] = float(value)

        for i, value in enumerate(hog_features):
            record[f"hog_{i}"] = float(value)

        records.append(record)

    return pd.DataFrame(records), sift_kmeans


def build_training_feature_dataframe(manifest_path, use_manifest_hsv=True):
    manifest_path = os.path.abspath(manifest_path)
    manifest_dir = os.path.dirname(manifest_path)
    bundle_root = os.path.dirname(manifest_dir)
    path_roots = [bundle_root, manifest_dir, os.getcwd()]

    manifest_df = pd.read_csv(manifest_path)
    return build_training_feature_dataframe_from_manifest_df(
        manifest_df,
        use_manifest_hsv,
        path_roots=path_roots,
    )


def train_model_package_from_feature_df(
    feature_df,
    sift_kmeans,
    model_output_path,
    c=100,
    gamma=0.01,
    hsv_weight=0.85,
    sift_weight=0.10,
    hog_weight=0.05,
    kernel="rbf",
):
    feature_df = feature_df.copy()
    X = feature_df.drop(columns=["label"])
    y = feature_df["label"].astype(str)

    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    hsv_cols = detect_hsv_columns(X)
    sift_cols = detect_sift_columns(X)
    hog_cols = detect_hog_columns(X)

    if not hsv_cols:
        raise ValueError("No HSV columns found in training features.")
    if not sift_cols:
        raise ValueError("No SIFT columns found in training features.")
    if not hog_cols:
        raise ValueError("No HOG columns found in training features.")

    model = Pipeline([
        (
            "feature_balance",
            MultiFeatureWeighter(
                hsv_cols=hsv_cols,
                sift_cols=sift_cols,
                hog_cols=hog_cols,
                hsv_weight=hsv_weight,
                sift_weight=sift_weight,
                hog_weight=hog_weight,
            ),
        ),
        (
            "clf",
            SVC(
                kernel=kernel,
                C=c,
                gamma=gamma,
                probability=False,
            ),
        ),
    ])
    model.fit(X, y_encoded)

    model_package = {
        "model": model,
        "label_encoder": label_encoder,
        "sift_kmeans": sift_kmeans,
        "hsv_cols": hsv_cols,
        "sift_cols": sift_cols,
        "hog_cols": hog_cols,
        "feature_columns": list(X.columns),
        "board_size": BOARD_SIZE,
        "tile_size": DEFAULT_TILE_SIZE,
        "classes": label_encoder.classes_.tolist(),
        "best_params": {
            "C": c,
            "gamma": gamma,
            "kernel": kernel,
            "hsv_weight": hsv_weight,
            "sift_weight": sift_weight,
            "hog_weight": hog_weight,
        },
        "feature_params": {
            "hog_orientations": HOG_ORIENTATIONS,
            "hog_pixels_per_cell": HOG_PIXELS_PER_CELL,
            "hog_cells_per_block": HOG_CELLS_PER_BLOCK,
            "hog_block_norm": HOG_BLOCK_NORM,
            "sift_vocab_size": SIFT_VOCAB_SIZE,
            "sift_max_descriptors_per_image": SIFT_MAX_DESCRIPTORS_PER_IMAGE,
            "random_state": RANDOM_STATE,
        },
    }

    if model_output_path:
        os.makedirs(os.path.dirname(model_output_path), exist_ok=True)
        with open(model_output_path, "wb") as f:
            pickle.dump(model_package, f)

    return model_package, feature_df


def train_model_package_from_manifest_df(
    manifest_df,
    model_output_path,
    c=100,
    gamma=0.01,
    hsv_weight=0.85,
    sift_weight=0.10,
    hog_weight=0.05,
    kernel="rbf",
):
    feature_df, sift_kmeans = build_training_feature_dataframe_from_manifest_df(manifest_df)
    return train_model_package_from_feature_df(
        feature_df=feature_df,
        sift_kmeans=sift_kmeans,
        model_output_path=model_output_path,
        c=c,
        gamma=gamma,
        hsv_weight=hsv_weight,
        sift_weight=sift_weight,
        hog_weight=hog_weight,
        kernel=kernel,
    )


def train_model_package(
    manifest_path,
    model_output_path,
    c=100,
    gamma=0.01,
    hsv_weight=0.85,
    sift_weight=0.10,
    hog_weight=0.05,
    kernel="rbf",
):
    feature_df, sift_kmeans = build_training_feature_dataframe(manifest_path)
    return train_model_package_from_feature_df(
        feature_df=feature_df,
        sift_kmeans=sift_kmeans,
        model_output_path=model_output_path,
        c=c,
        gamma=gamma,
        hsv_weight=hsv_weight,
        sift_weight=sift_weight,
        hog_weight=hog_weight,
        kernel=kernel,
    )


def load_model_package(model_path):
    with open(model_path, "rb") as f:
        package = pickle.load(f)

    required_keys = [
        "model",
        "label_encoder",
        "sift_kmeans",
        "hsv_cols",
        "sift_cols",
        "hog_cols",
        "feature_columns",
    ]
    missing = [key for key in required_keys if key not in package]
    if missing:
        raise ValueError(f"Model package is missing keys needed for unseen prediction: {missing}")

    return package


def split_board_into_tiles(image, board_size=BOARD_SIZE):
    height, width = image.shape[:2]
    x_edges = np.linspace(0, width, board_size + 1, dtype=int)
    y_edges = np.linspace(0, height, board_size + 1, dtype=int)

    tiles = []
    for row in range(board_size):
        for col in range(board_size):
            x1, x2 = int(x_edges[col]), int(x_edges[col + 1])
            y1, y2 = int(y_edges[row]), int(y_edges[row + 1])
            tiles.append({
                "row": row,
                "col": col,
                "x1": x1,
                "y1": y1,
                "x2": x2,
                "y2": y2,
                "tile": image[y1:y2, x1:x2],
            })

    return tiles


def build_board_feature_dataframe(image_path, model_package):
    image = read_image_bgr(image_path)
    board_size = int(model_package.get("board_size", BOARD_SIZE))
    tile_size = tuple(model_package.get("tile_size", DEFAULT_TILE_SIZE))
    sift = create_sift()

    rows = []
    for item in split_board_into_tiles(image, board_size):
        tile = resize_tile(item["tile"], tile_size)
        hsv_values = extract_hsv_feature_values(tile, tile_size)
        descriptors, num_keypoints = extract_sift_descriptors(tile, sift, tile_size)
        sift_hist = descriptors_to_sift_histogram(descriptors, model_package["sift_kmeans"])
        hog_features = extract_hog_feature_array(tile, tile_size)

        record = {
            "image_id": 0,
            "row": item["row"],
            "col": item["col"],
            "x1": item["x1"],
            "y1": item["y1"],
            "x2": item["x2"],
            "y2": item["y2"],
            "tile_image_path": "",
            "csv_file": "",
            "img_width": int(tile.shape[1]),
            "img_height": int(tile.shape[0]),
            "num_sift_keypoints": int(num_keypoints),
        }

        record.update(values_to_columns(hsv_values, model_package["hsv_cols"]))

        sift_cols = [col for col in model_package["sift_cols"] if col.startswith("sift_")]
        record.update(array_to_columns(sift_hist, sift_cols))

        hog_cols = [col for col in model_package["hog_cols"] if col.startswith("hog_")]
        record.update(array_to_columns(hog_features, hog_cols))

        rows.append(record)

    return pd.DataFrame(rows)


def align_features_for_model(feature_df, model_package):
    aligned = feature_df.copy()
    for col in model_package["feature_columns"]:
        if col not in aligned.columns:
            aligned[col] = 0.0
    return aligned[model_package["feature_columns"]]


def predict_board(image_path, model_package):
    feature_df = build_board_feature_dataframe(image_path, model_package)
    X = align_features_for_model(feature_df, model_package)

    encoded_predictions = model_package["model"].predict(X)
    labels = model_package["label_encoder"].inverse_transform(encoded_predictions)

    result_df = feature_df[["row", "col", "x1", "y1", "x2", "y2"]].copy()
    result_df["predicted_label"] = labels

    try:
        scores = model_package["model"].decision_function(X)
        if np.ndim(scores) == 1:
            margins = np.abs(scores)
        else:
            margins = np.max(scores, axis=1)
        result_df["decision_margin"] = margins
    except Exception:
        result_df["decision_margin"] = np.nan

    board_size = int(model_package.get("board_size", BOARD_SIZE))
    board = labels.reshape(board_size, board_size)

    return result_df, board


def draw_prediction_overlay(image_path, predictions_df, output_path):
    image = read_image_bgr(image_path)
    output = image.copy()

    for _, row in predictions_df.iterrows():
        x1, y1, x2, y2 = int(row["x1"]), int(row["y1"]), int(row["x2"]), int(row["y2"])
        label = str(row["predicted_label"])
        tile_w = max(1, x2 - x1)
        tile_h = max(1, y2 - y1)
        font_scale = max(0.35, min(tile_w, tile_h) / 180.0)
        thickness = max(1, int(round(font_scale * 2)))

        cv.rectangle(output, (x1, y1), (x2, y2), (255, 255, 255), 2)

        text_size, baseline = cv.getTextSize(label, cv.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
        text_w, text_h = text_size
        text_x = x1 + 6
        text_y = y1 + text_h + 8
        bg_x2 = min(x2 - 2, text_x + text_w + 8)
        bg_y2 = min(y2 - 2, text_y + baseline + 4)

        cv.rectangle(output, (x1 + 2, y1 + 2), (bg_x2, bg_y2), (0, 0, 0), -1)
        cv.putText(
            output,
            label,
            (text_x, text_y),
            cv.FONT_HERSHEY_SIMPLEX,
            font_scale,
            (255, 255, 255),
            thickness,
            cv.LINE_AA,
        )

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    ok = cv.imwrite(output_path, output)
    if not ok:
        raise ValueError(f"Could not write prediction overlay: {output_path}")

    return output_path


def print_board(board):
    for row in board:
        print(" | ".join(str(value) for value in row))
