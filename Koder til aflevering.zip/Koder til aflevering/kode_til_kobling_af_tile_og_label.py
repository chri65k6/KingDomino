import os
import re
import glob
import shutil
import pandas as pd


# =========================================================
# KONFIGURATION
# =========================================================

# Mappe med dine tile_data_*.csv filer
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FOLDER = os.path.join(SCRIPT_DIR, "tile_data")

# Rodmappe med tile-billederne (søger rekursivt i alle undermapper)
TILE_IMAGE_ROOT = os.path.join(SCRIPT_DIR, "processed_tiles")

# Outputmappe
OUTPUT_FOLDER = os.path.join(SCRIPT_DIR, "ground_truth_dataset")

# Sæt til True hvis billeder også skal kopieres til mapper opdelt efter label
COPY_IMAGES_INTO_LABEL_FOLDERS = False


# =========================================================
# HJÆLPEFUNKTIONER
# =========================================================

def normalize_colname(name):
    if name is None:
        return ""
    return str(name).strip().lower()


def safe_make_dir(path):
    os.makedirs(path, exist_ok=True)


def to_bundle_relative(path):
    return os.path.relpath(path, SCRIPT_DIR)


def find_csv_files(folder):
    pattern = os.path.join(folder, "tile_data_*.csv")
    files = sorted(glob.glob(pattern))

    if not files:
        raise FileNotFoundError(f"Ingen CSV-filer fundet med mønster: {pattern}")

    return files


def extract_image_id_from_csv(csv_path):
    """
    Understøtter fx:
    tile_data_3.csv
    tile_data_hist_3.csv
    """
    filename = os.path.basename(csv_path)
    match = re.search(r"tile_data(?:_hist)?_(\d+)\.csv$", filename, re.IGNORECASE)

    if not match:
        raise ValueError(f"Kan ikke udlede image_id fra filnavn: {filename}")

    return int(match.group(1))


def read_csv_robust(csv_path):
    """
    Robust CSV-indlæsning.
    Forventer primært semikolon-separerede filer.
    Håndterer også trailing semicolon i header.
    """
    df = pd.read_csv(csv_path, sep=";")

    # Hvis alt er læst som én kolonne, prøv komma
    if len(df.columns) == 1:
        df = pd.read_csv(csv_path, sep=",")

    # Fjern helt tomme kolonner
    df = df.dropna(axis=1, how="all")

    # Rens kolonnenavne
    cleaned_columns = []
    for col in df.columns:
        if col is None:
            cleaned_columns.append("")
        else:
            cleaned_columns.append(str(col).strip())

    df.columns = cleaned_columns
    return df


def detect_row_col_columns(df):
    """
    Finder koordinatkolonner robust.

    Prioritering:
    row = y
    col = x

    Understøtter også row/col, r/c, tile_row/tile_col.
    """
    cols = {normalize_colname(c): c for c in df.columns}

    row_candidates = ["row", "tile_row", "grid_row", "r", "y"]
    col_candidates = ["col", "tile_col", "grid_col", "c", "x"]

    row_col = None
    col_col = None

    for candidate in row_candidates:
        if candidate in cols:
            row_col = cols[candidate]
            break

    for candidate in col_candidates:
        if candidate in cols:
            col_col = cols[candidate]
            break

    if row_col is None or col_col is None:
        raise ValueError(
            "Kunne ikke finde række/kolonne-kolonner i CSV. "
            f"Tilgængelige kolonner: {list(df.columns)}"
        )

    return row_col, col_col


def detect_label_column(df):
    """
    Finder label-kolonnen.
    Hvis ingen kendt kolonne findes, bruges sidste kolonne.
    """
    cols = {normalize_colname(c): c for c in df.columns}

    label_candidates = [
        "label",
        "terrain",
        "terrain_type",
        "class",
        "target",
        "ground_truth"
    ]

    for candidate in label_candidates:
        if candidate in cols:
            return cols[candidate]

    return df.columns[-1]


def clean_label(value):
    if pd.isna(value):
        return None

    value = str(value).strip().lower()

    if value == "":
        return None

    return value


def find_all_tile_images(root_folder):
    """
    Finder alle tile-billeder rekursivt.
    Returnerer dict:
    (image_id, row, col) -> filepath
    """
    print(f"\n[DEBUG] Leder efter tile-billeder under:")
    print(os.path.abspath(root_folder))

    if not os.path.exists(root_folder):
        raise FileNotFoundError(f"Mappen findes ikke: {os.path.abspath(root_folder)}")

    png_files = glob.glob(os.path.join(root_folder, "**", "*.png"), recursive=True)
    print(f"[DEBUG] Antal PNG-filer fundet rekursivt: {len(png_files)}")

    if png_files[:10]:
        print("[DEBUG] Eksempler på PNG-filer:")
        for f in png_files[:10]:
            print("   ", f)

    pattern = os.path.join(root_folder, "**", "image_*_r*_c*.png")
    files = glob.glob(pattern, recursive=True)

    print(f"[DEBUG] Antal filer der matcher image_*_r*_c*.png: {len(files)}")

    if files[:10]:
        print("[DEBUG] Eksempler på matchende tile-filer:")
        for f in files[:10]:
            print("   ", f)

    if not files:
        raise FileNotFoundError(
            f"Ingen tile-billeder fundet under {root_folder} med mønster image_*_r*_c*.png"
        )

    image_map = {}

    for path in files:
        filename = os.path.basename(path)
        match = re.match(r"image_(\d+)_r(\d+)_c(\d+)\.png$", filename, re.IGNORECASE)

        if not match:
            continue

        image_id = int(match.group(1))
        row = int(match.group(2))
        col = int(match.group(3))

        key = (image_id, row, col)

        if key in image_map:
            print(f"ADVARSEL: Dublet fundet for {key}")
            print(f"  Eksisterende: {image_map[key]}")
            print(f"  Ny:          {path}")

        image_map[key] = path

    return image_map


# =========================================================
# KERNELOGIK
# =========================================================

def build_ground_truth_manifest(csv_folder, tile_image_root, output_folder):
    csv_files = find_csv_files(csv_folder)
    image_map = find_all_tile_images(tile_image_root)

    safe_make_dir(output_folder)

    matched_rows = []
    missing_images = []
    missing_csv_rows = []
    duplicate_csv_keys = []

    all_csv_keys = set()

    for csv_path in csv_files:
        image_id = extract_image_id_from_csv(csv_path)
        df = read_csv_robust(csv_path)

        print(f"\n[DEBUG] CSV-fil: {csv_path}")
        print(f"[DEBUG] Kolonner: {list(df.columns)}")

        if df.empty:
            print(f"ADVARSEL: Tom CSV-fil springes over: {csv_path}")
            continue

        row_col, col_col = detect_row_col_columns(df)
        label_col = detect_label_column(df)

        print(f"[DEBUG] Bruger row_col = {row_col}, col_col = {col_col}, label_col = {label_col}")

        # Rens labels
        df[label_col] = df[label_col].apply(clean_label)

        # Fjern rækker uden label
        df = df[df[label_col].notna()].copy()

        # Konverter koordinater
        df[row_col] = pd.to_numeric(df[row_col], errors="coerce")
        df[col_col] = pd.to_numeric(df[col_col], errors="coerce")
        df = df[df[row_col].notna() & df[col_col].notna()].copy()

        df[row_col] = df[row_col].astype(int)
        df[col_col] = df[col_col].astype(int)

        # Dubletcheck i CSV
        duplicated = df.duplicated(subset=[row_col, col_col], keep=False)
        if duplicated.any():
            dup_df = df.loc[duplicated, [row_col, col_col, label_col]]
            for _, row in dup_df.iterrows():
                duplicate_csv_keys.append({
                    "csv_file": to_bundle_relative(os.path.abspath(csv_path)),
                    "image_id": image_id,
                    "row": int(row[row_col]),
                    "col": int(row[col_col]),
                    "label": row[label_col]
                })

        # Match hver CSV-række med billedfil
        for _, row in df.iterrows():
            r = int(row[row_col])
            c = int(row[col_col])
            label = row[label_col]

            key = (image_id, r, c)
            all_csv_keys.add(key)

            image_path = image_map.get(key)

            if image_path is None:
                missing_images.append({
                    "image_id": image_id,
                    "row": r,
                    "col": c,
                    "label": label,
                    "csv_file": to_bundle_relative(os.path.abspath(csv_path))
                })
                continue

            record = {
                "image_id": image_id,
                "row": r,
                "col": c,
                "label": label,
                "tile_image_path": to_bundle_relative(os.path.abspath(image_path)),
                "csv_file": to_bundle_relative(os.path.abspath(csv_path))
            }

            # Tilføj øvrige kolonner som metadata
            for col in df.columns:
                if col in [row_col, col_col, label_col]:
                    continue
                record[col] = row[col]

            matched_rows.append(record)

    # Find billeder som ikke har match i CSV
    for (image_id, r, c), path in image_map.items():
        if (image_id, r, c) not in all_csv_keys:
            missing_csv_rows.append({
                "image_id": image_id,
                "row": r,
                "col": c,
                "tile_image_path": to_bundle_relative(os.path.abspath(path))
            })

    manifest_df = pd.DataFrame(matched_rows)
    missing_images_df = pd.DataFrame(missing_images)
    missing_csv_rows_df = pd.DataFrame(missing_csv_rows)
    duplicate_csv_keys_df = pd.DataFrame(duplicate_csv_keys)

    manifest_path = os.path.join(output_folder, "ground_truth_manifest.csv")
    missing_images_path = os.path.join(output_folder, "missing_images.csv")
    missing_csv_rows_path = os.path.join(output_folder, "images_without_csv_match.csv")
    duplicate_csv_keys_path = os.path.join(output_folder, "duplicate_csv_keys.csv")
    summary_path = os.path.join(output_folder, "dataset_summary.txt")

    manifest_df.to_csv(manifest_path, index=False, encoding="utf-8")
    missing_images_df.to_csv(missing_images_path, index=False, encoding="utf-8")
    missing_csv_rows_df.to_csv(missing_csv_rows_path, index=False, encoding="utf-8")
    duplicate_csv_keys_df.to_csv(duplicate_csv_keys_path, index=False, encoding="utf-8")

    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("GROUND TRUTH DATASET SUMMARY\n")
        f.write("=" * 40 + "\n")
        f.write(f"Antal matchede tiles: {len(manifest_df)}\n")
        f.write(f"Manglende billeder ift. CSV: {len(missing_images_df)}\n")
        f.write(f"Billeder uden CSV-match: {len(missing_csv_rows_df)}\n")
        f.write(f"Dubletter i CSV-koordinater: {len(duplicate_csv_keys_df)}\n\n")

        if not manifest_df.empty and "label" in manifest_df.columns:
            f.write("Label-fordeling:\n")
            f.write(manifest_df["label"].value_counts().to_string())
            f.write("\n")

    return manifest_df, missing_images_df, missing_csv_rows_df, duplicate_csv_keys_df


def copy_images_into_label_folders(manifest_df, output_folder):
    """
    Valgfrit:
    Kopierer billeder til mapper opdelt efter label.
    """
    by_label_root = os.path.join(output_folder, "by_label")
    safe_make_dir(by_label_root)

    for _, row in manifest_df.iterrows():
        label = str(row["label"]).strip()
        src = os.path.join(SCRIPT_DIR, row["tile_image_path"])

        label_folder = os.path.join(by_label_root, label)
        safe_make_dir(label_folder)

        filename = f"image_{row['image_id']}_r{row['row']}_c{row['col']}.png"
        dst = os.path.join(label_folder, filename)

        shutil.copy2(src, dst)


# =========================================================
# MAIN
# =========================================================

def main():
    print("+--------------------------------------+")
    print("| King Domino ground-truth dataset     |")
    print("+--------------------------------------+")

    manifest_df, missing_images_df, missing_csv_rows_df, duplicate_csv_keys_df = \
        build_ground_truth_manifest(
            csv_folder=CSV_FOLDER,
            tile_image_root=TILE_IMAGE_ROOT,
            output_folder=OUTPUT_FOLDER
        )

    print(f"\nMatchede tiles: {len(manifest_df)}")
    print(f"Manglende billeder ift. CSV: {len(missing_images_df)}")
    print(f"Billeder uden CSV-match: {len(missing_csv_rows_df)}")
    print(f"Dubletter i CSV: {len(duplicate_csv_keys_df)}")

    if not manifest_df.empty:
        print("\nLabel-fordeling:")
        print(manifest_df["label"].value_counts())

    if COPY_IMAGES_INTO_LABEL_FOLDERS and not manifest_df.empty:
        copy_images_into_label_folders(manifest_df, OUTPUT_FOLDER)
        print("\nBilleder er kopieret til label-mapper.")

    print(f"\nOutput gemt i:\n{os.path.abspath(OUTPUT_FOLDER)}")


if __name__ == "__main__":
    main()
