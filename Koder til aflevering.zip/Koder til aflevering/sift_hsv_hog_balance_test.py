import os
import numpy as np
import pandas as pd

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.svm import SVC
from sklearn.model_selection import GroupKFold, GridSearchCV
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# =========================================================
# KONFIGURATION
# =========================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GROUND_TRUTH_DIR = os.path.join(SCRIPT_DIR, "ground_truth_dataset")
MODEL_SELECTION_DIR = os.path.join(SCRIPT_DIR, "model_selection_results")

SIFT_PATH = os.path.join(GROUND_TRUTH_DIR, "ground_truth_with_sift.csv")
HOG_PATH = os.path.join(GROUND_TRUTH_DIR, "ground_truth_with_hog.csv")

N_SPLITS = 5

SVM_KERNEL = "rbf"
SVM_C_VALUES = [1, 10, 100]
SVM_GAMMA_VALUES = [0.01, 0.001, 0.0001]
WEIGHT_STEP = 0.05

GRID_N_JOBS = -1
OUTPUT_RESULTS_CSV = os.path.join(
    MODEL_SELECTION_DIR,
    "grid_search_hsv_sift_hog_merged_results.csv",
)


# =========================================================
# HJÆLPEFUNKTIONER
# =========================================================

def validate_basic_columns(df, name="DataFrame"):
    required_cols = ["image_id", "label"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"{name} mangler nødvendige kolonner: {missing}")


def unique_preserve_order(seq):
    return list(dict.fromkeys(seq))


def detect_hsv_columns(df):
    exact_names = {
        "hue", "saturation", "value",
        "mean_h", "mean_s", "mean_v",
        "std_h", "std_s", "std_v"
    }

    prefixes = (
        "hsv_", "hist_h_", "hist_s_", "hist_v_",
        "h_bin_", "s_bin_", "v_bin_"
    )

    contains_tokens = ("hue", "saturation", "value", "hsv")

    cols = []
    for col in df.columns:
        c = col.lower()
        if c in exact_names:
            cols.append(col)
        elif c.startswith(prefixes):
            cols.append(col)
        elif any(token in c for token in contains_tokens):
            if c not in ("label", "image_id"):
                cols.append(col)

    return unique_preserve_order(cols)


def detect_sift_columns(df):
    cols = []
    for col in df.columns:
        c = col.lower()
        if "sift" in c and c not in ("label", "image_id"):
            cols.append(col)
    return unique_preserve_order(cols)


def detect_hog_columns(df):
    cols = []
    for col in df.columns:
        c = col.lower()
        if "hog" in c and c not in ("label", "image_id"):
            cols.append(col)
    return unique_preserve_order(cols)


def choose_merge_keys(df1, df2):
    """
    Finder automatisk de bedste merge-nøgler.
    Prioriterer typiske tile-identifikatorer.
    """
    preferred_keys = [
        ["image_id", "row", "col"],
        ["image_id", "tile_row", "tile_col"],
        ["image_id", "x", "y"],
        ["image_id", "tile_id"],
        ["image_id", "tile_index"],
        ["image_id", "index"],
        ["image_id"]
    ]

    cols1 = set(df1.columns)
    cols2 = set(df2.columns)

    for keys in preferred_keys:
        if all(k in cols1 and k in cols2 for k in keys):
            return keys

    common = [c for c in df1.columns if c in df2.columns]

    # label skal ikke bruges som merge-nøgle
    common = [c for c in common if c != "label"]

    if "image_id" in common:
        return common

    raise ValueError(
        "Kunne ikke finde passende merge-kolonner mellem de to filer. "
        "Tjek at begge filer har fx image_id + row/col eller image_id + tile_id."
    )


def merge_feature_files(sift_path, hog_path):
    if not os.path.isfile(sift_path):
        raise FileNotFoundError(f"SIFT-fil ikke fundet: {sift_path}")
    if not os.path.isfile(hog_path):
        raise FileNotFoundError(f"HOG-fil ikke fundet: {hog_path}")

    df_sift = pd.read_csv(sift_path)
    df_hog = pd.read_csv(hog_path)

    validate_basic_columns(df_sift, "SIFT-fil")
    validate_basic_columns(df_hog, "HOG-fil")

    merge_keys = choose_merge_keys(df_sift, df_hog)
    print("\nBruger merge-nøgler:", merge_keys)

    # Undgå at merge dublerede featurekolonner
    # Vi vil kun beholde features fra HOG-filen som ikke allerede findes i SIFT-filen,
    # undtagen merge keys + label
    cols_to_take_from_hog = []
    for col in df_hog.columns:
        if col in merge_keys or col == "label":
            continue
        if col not in df_sift.columns:
            cols_to_take_from_hog.append(col)

    df_hog_reduced = df_hog[merge_keys + ["label"] + cols_to_take_from_hog].copy()

    merged = pd.merge(
        df_sift,
        df_hog_reduced,
        on=merge_keys,
        how="inner",
        suffixes=("", "_hogdup")
    )

    # Hvis begge filer havde label, får vi label og label_hogdup
    if "label_hogdup" in merged.columns:
        mismatch = merged[
            merged["label"].astype(str).fillna("") != merged["label_hogdup"].astype(str).fillna("")
        ]
        if len(mismatch) > 0:
            print(f"Advarsel: {len(mismatch)} rækker har forskellig label mellem filerne.")
            print("Beholder label fra SIFT-filen.")
        merged = merged.drop(columns=["label_hogdup"])

    merged = merged.dropna(subset=["label"]).copy()

    print(f"SIFT-rækker:  {len(df_sift)}")
    print(f"HOG-rækker:   {len(df_hog)}")
    print(f"Merge-rækker: {len(merged)}")

    return merged


def build_weight_combinations(step=0.25):
    weights = []
    values = np.arange(0.0, 1.0 + 1e-9, step)

    for hsv_w in values:
        for sift_w in values:
            hog_w = 1.0 - hsv_w - sift_w
            if hog_w < -1e-9:
                continue
            if hog_w < 0:
                hog_w = 0.0

            weights.append((
                round(float(hsv_w), 2),
                round(float(sift_w), 2),
                round(float(hog_w), 2)
            ))

    return unique_preserve_order(weights)


# =========================================================
# CUSTOM TRANSFORMER
# =========================================================

class MultiFeatureWeighter(BaseEstimator, TransformerMixin):
    def __init__(
        self,
        hsv_cols=None,
        sift_cols=None,
        hog_cols=None,
        hsv_weight=1.0,
        sift_weight=0.0,
        hog_weight=0.0
    ):
        self.hsv_cols = hsv_cols
        self.sift_cols = sift_cols
        self.hog_cols = hog_cols
        self.hsv_weight = hsv_weight
        self.sift_weight = sift_weight
        self.hog_weight = hog_weight

    def fit(self, X, y=None):
        if not isinstance(X, pd.DataFrame):
            raise TypeError("MultiFeatureWeighter forventer en pandas DataFrame.")

        self.hsv_cols_ = self.hsv_cols if self.hsv_cols is not None else detect_hsv_columns(X)
        self.sift_cols_ = self.sift_cols if self.sift_cols is not None else detect_sift_columns(X)
        self.hog_cols_ = self.hog_cols if self.hog_cols is not None else detect_hog_columns(X)

        if len(self.hsv_cols_) == 0:
            raise ValueError("Ingen HSV-kolonner fundet.")
        if len(self.sift_cols_) == 0:
            raise ValueError("Ingen SIFT-kolonner fundet.")
        if len(self.hog_cols_) == 0:
            raise ValueError("Ingen HOG-kolonner fundet.")

        self.hsv_scaler_ = StandardScaler()
        self.sift_scaler_ = StandardScaler()
        self.hog_scaler_ = StandardScaler()

        self.hsv_scaler_.fit(X[self.hsv_cols_])
        self.sift_scaler_.fit(X[self.sift_cols_])
        self.hog_scaler_.fit(X[self.hog_cols_])

        return self

    def transform(self, X):
        hsv_part = self.hsv_scaler_.transform(X[self.hsv_cols_]) * self.hsv_weight
        sift_part = self.sift_scaler_.transform(X[self.sift_cols_]) * self.sift_weight
        hog_part = self.hog_scaler_.transform(X[self.hog_cols_]) * self.hog_weight

        return np.hstack([hsv_part, sift_part, hog_part])


# =========================================================
# MAIN
# =========================================================

def main():
    df = merge_feature_files(SIFT_PATH, HOG_PATH)

    validate_basic_columns(df, "Merged data")

    X = df.drop(columns=["label"])
    y = df["label"].astype(str)
    groups = df["image_id"]

    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    hsv_cols = detect_hsv_columns(X)
    sift_cols = detect_sift_columns(X)
    hog_cols = detect_hog_columns(X)

    print("\n=== FUNDNE FEATURE-GRUPPER EFTER MERGE ===")
    print(f"HSV-kolonner:  {len(hsv_cols)}")
    print(f"SIFT-kolonner: {len(sift_cols)}")
    print(f"HOG-kolonner:  {len(hog_cols)}")

    if len(hsv_cols) == 0:
        raise ValueError("Ingen HSV-kolonner fundet efter merge.")
    if len(sift_cols) == 0:
        raise ValueError("Ingen SIFT-kolonner fundet efter merge.")
    if len(hog_cols) == 0:
        raise ValueError("Ingen HOG-kolonner fundet efter merge.")

    print("\nEksempel HSV:", hsv_cols[:10])
    print("Eksempel SIFT:", sift_cols[:10])
    print("Eksempel HOG:", hog_cols[:10])

    pipeline = Pipeline([
        (
            "feature_balance",
            MultiFeatureWeighter(
                hsv_cols=hsv_cols,
                sift_cols=sift_cols,
                hog_cols=hog_cols
            )
        ),
        ("clf", SVC(kernel=SVM_KERNEL))
    ])

    weight_combinations = build_weight_combinations(step=WEIGHT_STEP)
    print(f"\nAntal vægtkombinationer: {len(weight_combinations)}")

    param_grid = []
    for hsv_w, sift_w, hog_w in weight_combinations:
        param_grid.append({
            "feature_balance__hsv_weight": [hsv_w],
            "feature_balance__sift_weight": [sift_w],
            "feature_balance__hog_weight": [hog_w],
            "clf__C": SVM_C_VALUES,
            "clf__gamma": SVM_GAMMA_VALUES
        })

    cv = GroupKFold(n_splits=N_SPLITS)

    grid = GridSearchCV(
        estimator=pipeline,
        param_grid=param_grid,
        scoring="accuracy",
        cv=cv,
        n_jobs=GRID_N_JOBS,
        verbose=2,
        refit=True,
        return_train_score=True
    )

    grid.fit(X, y_encoded, groups=groups)

    print("\n=== BEDSTE RESULTAT ===")
    print(f"Bedste CV accuracy: {grid.best_score_:.4f}")
    print("Bedste parametre:")
    for k, v in grid.best_params_.items():
        print(f"  {k}: {v}")

    results = pd.DataFrame(grid.cv_results_)
    selected_cols = [
        "mean_test_score",
        "std_test_score",
        "mean_train_score",
        "rank_test_score",
        "param_feature_balance__hsv_weight",
        "param_feature_balance__sift_weight",
        "param_feature_balance__hog_weight",
        "param_clf__C",
        "param_clf__gamma"
    ]

    results_view = results[selected_cols].sort_values(
        by=["rank_test_score", "mean_test_score"],
        ascending=[True, False]
    )

    print("\n=== TOP 20 KOMBINATIONER ===")
    print(results_view.head(20).to_string(index=False))

    os.makedirs(os.path.dirname(OUTPUT_RESULTS_CSV), exist_ok=True)
    results_view.to_csv(OUTPUT_RESULTS_CSV, index=False)
    print(f"\nResultater gemt i: {OUTPUT_RESULTS_CSV}")

    best_model = grid.best_estimator_
    y_pred = best_model.predict(X)

    print("\n=== FIT PÅ HELE DATASETTET (kun reference) ===")
    print(f"Accuracy: {accuracy_score(y_encoded, y_pred):.4f}")

    print("\nClassification report:")
    print(classification_report(
        y_encoded,
        y_pred,
        target_names=label_encoder.classes_,
        zero_division=0
    ))

    print("\nConfusion matrix:")
    print(confusion_matrix(y_encoded, y_pred))


if __name__ == "__main__":
    main()
